// ---------- Es 1: leggere e scrivere il testo ----------
const p = document.createElement("p")
p.textContent = "Testo di partenza"

console.log("Es 1 - testo attuale:", p.textContent)

p.textContent = "Testo nuovo"
console.log("Es 1 - dopo la modifica:", p.textContent)


// ---------- Es 2: costruire una lista e contarla ----------
const materie = ["TPSIT", "Sistemi", "Informatica"]

const ul = document.createElement("ul")

materie.forEach(m => {
  const li = document.createElement("li")
  li.textContent = m
  ul.appendChild(li)
})

const voci = ul.querySelectorAll("li")
console.log("Es 2 - voci:", voci.length)

voci.forEach(v => console.log("-", v.textContent))


// ---------- Es 3: bottone che cambia il titolo ----------
const titolo = document.querySelector("#titolo")
const bottone = document.querySelector("#bottone")
const ripristina = document.querySelector("#ripristina")

// salvo il testo iniziale prima di toccarlo
const testoIniziale = titolo.textContent

bottone.addEventListener("click", () => {
  titolo.textContent = "Hai premuto!"
})

ripristina.addEventListener("click", () => {
  titolo.textContent = testoIniziale
})


// ---------- Es 4: accendi e spegni con toggle ----------
const evidenzia = document.querySelector("#evidenzia")

evidenzia.addEventListener("click", () => {
  const attivo = titolo.classList.toggle("evidenziato")
  evidenzia.textContent = attivo ? "Togli evidenza" : "Evidenzia"
})


// ---------- Es 5: colore casuale ----------
const colori = ["#F7D6E0", "#D6F7E4", "#D6E4F7", "#F7EFD6", "#E8D6F7"]
const bottoneColore = document.querySelector("#colore")

bottoneColore.addEventListener("click", () => {
  const i = Math.floor(Math.random() * colori.length)
  document.body.style.background = colori[i]
})


// ---------- Es 6: lista da un campo di testo ----------
// ---------- Es 6 + 7: lista con aggiunta, cancellazione e contatore ----------
const campo = document.querySelector("#campo")
const aggiungi = document.querySelector("#aggiungi")
const lista = document.querySelector("#lista")
const conteggio = document.querySelector("#conteggio")

const aggiornaConteggio = () => {
  const n = lista.querySelectorAll("li").length
  conteggio.textContent = `Voci: ${n}`
}

aggiungi.addEventListener("click", () => {
  const testo = campo.value.trim()

  if (testo === "") return

  const li = document.createElement("li")
  li.textContent = testo
  lista.appendChild(li)

  campo.value = ""
  aggiornaConteggio()
})

// un solo listener, sul contenitore
lista.addEventListener("click", (e) => {
  if (e.target.tagName !== "LI") return
  e.target.remove()
  aggiornaConteggio()
})